// @ts-nocheck

import { authLoginV1 } from '../auth';
import { authRegisterV1 } from '../auth';
import { channelsCreateV1 } from '../channels';
import { channelJoinV1 } from '../channel';
import { channelInviteV1 } from '../channel';

import { clearV1 } from '../other';

const ERROR = { error: 'error' };

// inputs to authRegisterV1 functions to setup tests
const EMAIL_VALID = 'hayden.smith@unsw.edu.au';
const EMAIL_VALID_2 = 'josh.lim@student.unsw.edu.au';
const EMAIL_VALID_3 = 'yuanyuan.shi@student.unsw.edu.au';
const PASSWORD_VALID = 'password';
const FIRSTNAME_VALID = 'Hayden';
const LASTNAME_VALID = 'Smith';
const FIRSTNAME_VALID_2 = 'Josh';
const LASTNAME_VALID_2 = 'Lim';
const FIRSTNAME_VALID_3 = 'Yuanyuan';
const LASTNAME_VALID_3 = 'Shi';

const PASSWORD_INVALID = '';

// inputs for function channelsCreateV1 to setup tests
const CHANNEL_NAME_VALID = 'Imagine Dragons';
const CHANNEL_NAME_INVALID = '';
const ISPUBLIC_VALID = true;
const ISPUBLIC_INVALID = false;

beforeEach(() => {
  clearV1();
});

describe('channelInviteV1 return errors', () => {
  test('channelId does not refer to a valid channel', () => {
    const user1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID_2, LASTNAME_VALID_2);
    const result1 = channelsCreateV1(user1.authUserId, CHANNEL_NAME_INVALID, ISPUBLIC_VALID);
    const result2 = channelInviteV1(user1.authUserId, result1, user2.authUserId);
    expect(result2).toStrictEqual(ERROR);
  });

  test('uId does not refer to a valid user', () => {
    const user1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const result1 = authRegisterV1(EMAIL_VALID_2, PASSWORD_INVALID, FIRSTNAME_VALID_2, LASTNAME_VALID_2);
    const channel = channelsCreateV1(user1.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const result2 = channelInviteV1(user1.authUserId, channel.channelId, result1);
    expect(result2).toStrictEqual(ERROR);
  });

  test('uId refers to a user who is already a member of the channel', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const result = channelInviteV1(user.authUserId, channel.channelId, user.authUserId);
    expect(result).toStrictEqual(ERROR);
  });

  test('channelId is valid but the authorised user is not a member of the channel', () => {
    const user1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID_2, LASTNAME_VALID_2);
    const user3 = authRegisterV1(EMAIL_VALID_3, PASSWORD_VALID, FIRSTNAME_VALID_3, LASTNAME_VALID_3);
    const channel = channelsCreateV1(user1.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const result = channelInviteV1(user2.authUserId, channel.channelId, user3.authUserId);
    expect(result).toStrictEqual(ERROR);
  });
});

// implement more correct types later
describe('channelInviteV1 with correct inputs', () => {
  test('channel owner invites others', () => {
    const user1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID_2, LASTNAME_VALID_2);
    const channel = channelsCreateV1(user1.authUserId, CHANNEL_NAME_VALID, true);
    const result = channelInviteV1(user1.authUserId, channel.channelId, user2.authUserId);
    expect(result).toStrictEqual({});
  });

  test('channel member invites others', () => {
    const user1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID_2, LASTNAME_VALID_2);
    const user3 = authRegisterV1(EMAIL_VALID_3, PASSWORD_VALID, FIRSTNAME_VALID_3, LASTNAME_VALID_3);
    const channel = channelsCreateV1(user1.authUserId, CHANNEL_NAME_VALID, true);
    const result1 = channelJoinV1(user2.authUserId, channel.channelId);
    const result2 = channelInviteV1(user2.authUserId, channel.channelId, user3.authUserId);
    expect(result2).toStrictEqual({});
  });
});
