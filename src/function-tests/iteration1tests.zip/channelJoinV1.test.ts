// @ts-nocheck

import { channelJoinV1 } from '../channel';
import { authRegisterV1 } from '../auth';
import { channelsCreateV1 } from '../channels';

import { clearV1 } from '../other';

const ERROR = { error: 'error' };

// valid inputs to authRegisterV1 functions to setup tests
const EMAIL_VALID = 'hayden.smith@unsw.edu.au';
const EMAIL_VALID_2 = 'josh.lim@student.unsw.edu.au';
const PASSWORD_VALID = 'password';
const FIRSTNAME_VALID = 'Hayden';
const LASTNAME_VALID = 'Smith';
const FIRSTNAME_VALID_2 = 'Josh';
const LASTNAME_VALID_2 = 'Lim';

// inputs for function channelsCreateV1 to setup tests
const CHANNEL_NAME_VALID = 'Imagine Dragons';
const CHANNEL_NAME_INVALID = '';
const ISPUBLIC_VALID = true;
const ISPUBLIC_INVALID = false;

beforeEach(() => {
  clearV1();
});

describe('channelJoinV1 return errors', () => {
  test('channelId does not refer to a valid channel', () => {
    const user1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID_2, LASTNAME_VALID_2);
    const result1 = channelsCreateV1(user1.authUserId, CHANNEL_NAME_INVALID, ISPUBLIC_VALID);
    const result2 = channelJoinV1(user2.authUserId, result1);
    expect(result2).toStrictEqual(ERROR);
  });

  test('the authorised user is already a member of the channel', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const result = channelJoinV1(user.authUserId, channel.channelId);
    expect(result).toStrictEqual(ERROR);
  });

  //* **********************************
  //* ******received undefined**********
  //* **********************************
  test('channelId refers to a channel that is private and the authorised user is not already a channel member and is not a global owner', () => {
    const user1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID_2, LASTNAME_VALID_2);
    const channel = channelsCreateV1(user1.authUserId, CHANNEL_NAME_VALID, false);
    const result = channelJoinV1(user2.authUserId, channel.channelId);
    expect(result).toStrictEqual(ERROR);
  });
});

// implement more correct caces later
describe('channelJoinV1 tests with correct inputs', () => {
  test('channelJoinV1 correct return type', () => {
    const user1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID_2, LASTNAME_VALID_2);
    const channel = channelsCreateV1(user1.authUserId, CHANNEL_NAME_VALID, true);
    const result = channelJoinV1(user2.authUserId, channel.channelId);
    expect(result).toStrictEqual({});
  });
});
