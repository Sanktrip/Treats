// @ts-nocheck

import { channelsListV1 } from '../channels';
import { channelsCreateV1 } from '../channels';
import { channelJoinV1 } from '../channel';
import { authRegisterV1 } from '../auth';
import { clearV1 } from '../other';

// !!TODO!!: add tests that use channelJoin and channelInvite too!

const ERROR = { error: 'error' };

// valid inputs to authRegisterV1 function to setup tests
const EMAIL_VALID = 'hayden.smith@unsw.edu.au';
const EMAIL_VALID_2 = 'josh.lim@student.unsw.edu.au';
const PASSWORD_VALID = 'password';
const FIRSTNAME_VALID = 'Hayden';
const LASTNAME_VALID = 'Smith';

const CHANNEL_NAME_VALID = 'Imagine Dragons';
const ISPUBLIC_VALID = true;

beforeEach(() => {
  clearV1();
});

/// ///////////////////////////////////////////////////////////////////////////////
/// ----- testing if channelsListV1 functions properly given valid input ----- ///
/// ///////////////////////////////////////////////////////////////////////////////
describe('channelsListV1 test return value', () => {
  test('correct return type', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channels = channelsListV1(user.authUserId);

    expect(channels).toStrictEqual(
      expect.objectContaining({
        channels: expect.any(Array),
      })
    );
  });

  test('correct return value - user that is part of all channels', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel1 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channel2 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channel3 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channels = channelsListV1(user.authUserId);

    channels.channels = new Set(channels.channels);

    expect(channels).toStrictEqual({
      channels: new Set([
        {
          channelId: channel1.channelId,
          name: CHANNEL_NAME_VALID
        },
        {
          channelId: channel2.channelId,
          name: CHANNEL_NAME_VALID
        },
        {
          channelId: channel3.channelId,
          name: CHANNEL_NAME_VALID
        },
      ])
    });
  });

  test('correct return value - user that joined a channel later on', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel1 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channel2 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channel3 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);

    const joinResult = channelJoinV1(user2.authUserId, channel2.channelId);
    const joinResult2 = channelJoinV1(user2.authUserId, channel3.channelId);

    const channels = channelsListV1(user2.authUserId);

    channels.channels = new Set(channels.channels);

    expect(channels).toStrictEqual({
      channels: new Set([
        {
          channelId: channel2.channelId,
          name: CHANNEL_NAME_VALID
        },
        {
          channelId: channel3.channelId,
          name: CHANNEL_NAME_VALID
        },
      ])
    });
  });

  test('correct return value - user that is part of some channels', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel1 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channel2 = channelsCreateV1(user2.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channel3 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channel4 = channelsCreateV1(user2.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);

    const channels = channelsListV1(user.authUserId);

    channels.channels = new Set(channels.channels);

    expect(channels).toStrictEqual({
      channels: new Set([
        {
          channelId: channel1.channelId,
          name: CHANNEL_NAME_VALID
        },
        {
          channelId: channel3.channelId,
          name: CHANNEL_NAME_VALID
        },
      ])
    });
  });

  test('correct return value - user that is part of no channels', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel1 = channelsCreateV1(user2.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);
    const channel2 = channelsCreateV1(user2.authUserId, CHANNEL_NAME_VALID, ISPUBLIC_VALID);

    const channels = channelsListV1(user.authUserId);

    expect(channels).toStrictEqual({
      channels: []
    });
  });
});

/// //////////////////////////////////////////////////////////////////////
/// ----- testing if channelsListV1 returns errors where needed ----- ///
/// //////////////////////////////////////////////////////////////////////
describe.each([

  ['non-existent user (invalid authUserId)', 0]

])('channelsListV1 error handling', (error, authUserId) => {
  test(`returns error upon ${error}`, () => {
    const channels = channelsListV1(authUserId);
    expect(channels).toStrictEqual(ERROR);
  });
});
