// @ts-nocheck

import { channelsCreateV1 } from '../channels';
import { authRegisterV1 } from '../auth';
import { channelDetailsV1 } from '../channel';
import { userProfileV2 } from '../users';

import { clearV1 } from '../other';

import { expect } from '@jest/globals';

const ERROR = { error: 'error' };

// valid inputs to authRegisterV1 function to setup tests
const EMAIL_VALID = 'hayden.smith@unsw.edu.au';
const PASSWORD_VALID = 'password';
const FIRSTNAME_VALID = 'Hayden';
const LASTNAME_VALID = 'Smith';

const CHANNEL_NAME_VALID = 'Imagine Dragons';

beforeEach(() => {
  clearV1();
});

/// /////////////////////////////////////////////////////////////////////////////////
/// ----- testing if channelsCreateV1 functions properly given valid input ----- ///
/// /////////////////////////////////////////////////////////////////////////////////
describe('channelsCreateV1 test return value', () => {
  test('correct return type', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);

    expect(channel).toStrictEqual(
      expect.objectContaining({
        channelId: expect.any(Number),
      })
    );
  });

  test('generates unique channelId for three channels', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel1 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const channel2 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const channel3 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);

    expect(channel1.channelId).toBeDefined();
    expect(channel2.channelId).toBeDefined();
    expect(channel3.channelId).toBeDefined();
    expect(channel1.channelId).not.toEqual(channel2.channelId);
    expect(channel1.channelId).not.toEqual(channel3.channelId);
    expect(channel2.channelId).not.toEqual(channel3.channelId);
  });

  test('pushes correct data to dataStore', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);

    const channelDetails = channelDetailsV1(user.authUserId, channel.channelId);

    expect(channelDetails).toStrictEqual({
      name: CHANNEL_NAME_VALID,
      isPublic: true,
      ownerMembers: [userProfileV2(user.authUserId, user.authUserId).user],
      allMembers: [userProfileV2(user.authUserId, user.authUserId).user],
    });
  });
});

/// ////////////////////////////////////////////////////////////////////////
/// ----- testing if channelsCreateV1 returns errors where needed ----- ///
/// ////////////////////////////////////////////////////////////////////////
describe.each([

  ['channel name too long ( > 20 )', 'WE_LOVE_HAYDEN_SO_SO_MUCH', true],
  ['channel name too short ( < 1 )', '', true],

])('channelsCreateV1 error handling', (error, name, isPublic) => {
  test(`returns error upon ${error}`, () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel = channelsCreateV1(user.authUserId, name, isPublic);

    expect(channel).toStrictEqual(ERROR);
  });
});

describe('channelsCreateV1 error handling', () => {
  test('returns error upon non-existent user', () => {
    const channel = channelsCreateV1(0, CHANNEL_NAME_VALID, true);
    expect(channel).toStrictEqual(ERROR);
  });
});
