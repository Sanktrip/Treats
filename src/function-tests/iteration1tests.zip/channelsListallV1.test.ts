// @ts-nocheck

import { channelsListallV1 } from '../channels';
import { channelsCreateV1 } from '../channels';
import { authRegisterV1 } from '../auth';
import { clearV1 } from '../other';
import { expect } from '@jest/globals';

const EMAIL_VALID = 'hayden.smith@unsw.edu.au';
const EMAIL_VALID_2 = 'hayhay@gmail.com';
const PASSWORD_VALID = 'password';
const FIRSTNAME_VALID = 'Hayden';
const LASTNAME_VALID = 'Smith';

const CHANNEL_NAME_VALID = 'Imagine Dragons';

const ERROR = { error: 'error' };

beforeEach(() => {
  clearV1();
});

describe('returns correct output', () => {
  test('empty channels array', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const result = channelsListallV1(user.authUserId);
    expect(result).toStrictEqual({ channels: [] });
  });

  test('returns all channels when user is part of all channels', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel1 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const channel2 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const channel3 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const allChannels = channelsListallV1(user.authUserId);

    // use Set as order doesn't matter -- assumption
    allChannels.channels = new Set(allChannels.channels);

    expect(allChannels).toStrictEqual({
      channels: new Set([
        {
          channelId: channel1.channelId,
          name: CHANNEL_NAME_VALID,
        },
        {
          channelId: channel2.channelId,
          name: CHANNEL_NAME_VALID,
        },
        {
          channelId: channel3.channelId,
          name: CHANNEL_NAME_VALID,
        }
      ])
    });
  });

  test('returns all channels when user is part of some channels', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel1 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const channel2 = channelsCreateV1(user2.authUserId, CHANNEL_NAME_VALID, true);
    const channel3 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const channel4 = channelsCreateV1(user2.authUserId, CHANNEL_NAME_VALID, true);

    const allChannels = channelsListallV1(user.authUserId);

    // use Set as order doesn't matter -- assumption
    allChannels.channels = new Set(allChannels.channels);

    expect(allChannels).toStrictEqual({
      channels: new Set([
        {
          channelId: channel1.channelId,
          name: CHANNEL_NAME_VALID,
        },
        {
          channelId: channel2.channelId,
          name: CHANNEL_NAME_VALID,
        },
        {
          channelId: channel4.channelId,
          name: CHANNEL_NAME_VALID,
        },
        {
          channelId: channel3.channelId,
          name: CHANNEL_NAME_VALID,
        }
      ])
    });
  });

  test('returns all channels when user is part of no channels', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const user2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel1 = channelsCreateV1(user2.authUserId, CHANNEL_NAME_VALID, true);
    const channel2 = channelsCreateV1(user2.authUserId, CHANNEL_NAME_VALID, true);

    const allChannels = channelsListallV1(user.authUserId);

    // use Set as order doesn't matter -- assumption
    allChannels.channels = new Set(allChannels.channels);

    expect(allChannels).toStrictEqual({
      channels: new Set([
        {
          channelId: channel1.channelId,
          name: CHANNEL_NAME_VALID,
        },
        {
          channelId: channel2.channelId,
          name: CHANNEL_NAME_VALID,
        }
      ])
    });
  });
});

describe('correct error handling', () => {
  /* test('invalid authUserId', () => {
    const user = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const channel1 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const channel2 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);
    const channel3 = channelsCreateV1(user.authUserId, CHANNEL_NAME_VALID, true);

    const INVALID_USERID = user.authUserId + 1;

    const result = channelsListallV1(INVALID_USERID);
    expect(result).toStrictEqual(ERROR);
  }); */
});
