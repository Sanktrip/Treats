import { authLoginV1 } from '../auth';
import { authRegisterV1 } from '../auth';
import { clearV1 } from '../other';

import { expect } from '@jest/globals';

interface authUserId {
  authUserId: number,
  token: string
}

// STANDARD OUTPUTS
const ERROR = { error: 'error' };

// STANDARD INPUTS
const EMAIL_VALID = 'hayden.smith@unsw.edu.au';
const EMAIL_INVALID = 'josh.lim@student.unsw.edu.au';
const EMAIL_VALID_3 = 'fluffy.unicorns@mailinator.com';
const PASSWORD_VALID = 'password';
const FIRSTNAME_VALID = 'Hayden';
const LASTNAME_VALID = 'Smith';
const PASSWORD_INVALID = 'apple123';
const PASSWORD_INVALID_2 = 'haydenIstheGoat';

beforeEach(() => {
  clearV1();
});

describe('authLogin general test with correct inputs', () => {
  test('authLoginV1 correct return type', () => {
    const result1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const result = authLoginV1(EMAIL_VALID, PASSWORD_VALID);
    expect((result as authUserId).authUserId).toEqual((result1 as authUserId).authUserId);
  });
});

describe('authLogin general test with invalid password', () => {
  test('authLoginV1 error return type (invalid password)', () => {
    const regResult = authRegisterV1(EMAIL_VALID_3, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    expect(regResult).not.toEqual(ERROR);
    const result = authLoginV1(EMAIL_VALID_3, PASSWORD_INVALID);
    expect(result).toStrictEqual(ERROR);
  });
});

describe('authLogin general test with invalid email', () => {
  test('authLoginV1 error return type (invalid email)', () => {
    const regResult = authRegisterV1(EMAIL_VALID_3, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    expect(regResult).not.toEqual(ERROR);
    const result = authLoginV1(EMAIL_INVALID, PASSWORD_VALID);
    expect(result).toStrictEqual(ERROR);
  });
});

describe('authLogin general test with invalid email and password', () => {
  test('authLoginV1 error return type (invalid email)', () => {
    const regResult = authRegisterV1(EMAIL_VALID_3, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    expect(regResult).not.toEqual(ERROR);
    const result = authLoginV1(EMAIL_INVALID, PASSWORD_INVALID_2);
    expect(result).toStrictEqual(ERROR);
  });
});

describe('authLogin test with invalid registration', () => {
  test('authReigsterV1 with error return type', () => {
    const result = authRegisterV1('sank', 'p', FIRSTNAME_VALID, LASTNAME_VALID);
    expect(result).toStrictEqual(
      expect.objectContaining(ERROR)
    );
  });
  test('authLoginV1 error return type (invalid registration)', () => {
    const result = authLoginV1('sank', 'p');
    expect(result).toStrictEqual(ERROR);
  });
});

describe('authLogin test with no registration', () => {
  test('authLoginV1 with invalid inputs', () => {
    const result = authLoginV1(EMAIL_VALID, PASSWORD_VALID);
    expect(result).toStrictEqual(ERROR);
  });
});
