// @ts-nocheck

import { userProfileV2 } from '../users';
import { clearV1 } from '../other';
import { authRegisterV1 } from '../auth';

/**
 * Types of tests:
 *
 * 1. General Tests for expected usage
 * 2. Invald parameters i.e. incorrect authId, userID
 * 3. Edge cases
 *
 */

const ERROR = { error: 'error' };

describe('1. General Tests', () => {
  test('1.1. One register and retrieve', () => {
    clearV1();

    const authID = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');

    expect(userProfileV2(authID.authUserId, authID.authUserId)).toStrictEqual({
      user: {
        uId: 1,
        email: 'example@gmail.com',
        nameFirst: 'Hayden',
        nameLast: 'Smith',
        handleStr: 'haydensmith'
      }
    });
  });
  test('1.2. Two users, one id', () => {
    clearV1();

    const authID1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const authID2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');

    expect(userProfileV2(authID1.authUserId, authID2.authUserId)).toStrictEqual({
      user: {
        uId: 2,
        email: 'anotheremail@yahoo.com',
        nameFirst: 'Bill',
        nameLast: 'Harvey',
        handleStr: 'billharvey'
      }
    });
  });
  test('1.3. 5 users, ask for two different IDs', () => {
    clearV1();
    const authID1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const user1 = authID1.authUserId;
    const authID2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');
    const user2 = authID2.authUserId;
    const authID3 = authRegisterV1('aperson@outlook.com', 'qwerty', 'Bob', 'Marley');
    const user3 = authID3.authUserId;
    const authID4 = authRegisterV1('student@unsw.com', 'zxcvbb', 'Sam', 'Foo');
    const user4 = authID4.authUserId;
    const authID5 = authRegisterV1('maybe@gmail.com', 'asdfdsfsdfg', 'Water', 'Fire');
    const user5 = authID5.authUserId;

    expect(userProfileV2(user2, user4)).toStrictEqual({
      user: {
        uId: 4,
        email: 'student@unsw.com',
        nameFirst: 'Sam',
        nameLast: 'Foo',
        handleStr: 'samfoo'
      }
    });
    expect(userProfileV2(user5, user3)).toStrictEqual({
      user: {
        uId: 3,
        email: 'aperson@outlook.com',
        nameFirst: 'Bob',
        nameLast: 'Marley',
        handleStr: 'bobmarley'
      }
    });
  });
});

describe('2. Invalid Parameters', () => {
  /* test('2.1. Invalid authId', () => {
    clearV1();

    let authID1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    let authID2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');

    expect(userProfileV2(-999, authID1.authUserId)).toStrictEqual(ERROR);
  }); */
  test('2.2. Invalid userId', () => {
    clearV1();

    const authID1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const authID2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');

    expect(userProfileV2(authID1.authUserId, 10000)).toStrictEqual(ERROR);
  });
  /* test('2.3. Invalid authID and userId', () => {
    clearV1();

    let authID1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    let authID2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');

    expect(userProfileV2(8888, 10000)).toEqual(ERROR);
  }); */
});

describe('3. Edge cases', () => {
  test('3.1. No users have been registered', () => {
    clearV1();

    expect(userProfileV2(1, 1)).toStrictEqual(ERROR);
  });
  /* test('3.2. Zero is used as an Id', () => {
    clearV1();

    let authID1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');

    expect(userProfileV2(0, authID1.authUserId)).toStrictEqual(ERROR);
  }); */
  test('3.3. Multiple users have the same information, but different Ids and emails', () => {
    clearV1();

    const authID1 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');
    const authID2 = authRegisterV1('anotheremails@yahoo.com', 'letters67', 'Bill', 'Harvey');

    expect(userProfileV2(authID1.authUserId, authID2.authUserId)).toStrictEqual({
      user: {
        uId: 2,
        email: 'anotheremails@yahoo.com',
        nameFirst: 'Bill',
        nameLast: 'Harvey',
        handleStr: 'billharvey0'
      }
    });
  });
});
