// @ts-nocheck

import { authRegisterV1 } from '../auth';
import { clearV1 } from '../other';
import { userProfileV2 } from '../users';

import { expect } from '@jest/globals';

const ERROR = { error: 'error' };

const EMAIL_VALID = 'hayden.smith@unsw.edu.au';
const EMAIL_VALID_2 = 'josh.lim@student.unsw.edu.au';
const EMAIL_VALID_3 = 'fluffy.unicorns@mailinator.com';
const PASSWORD_VALID = 'password';
const FIRSTNAME_VALID = 'Hayden';
const LASTNAME_VALID = 'Smith';
const HANDLE_VALID = 'haydensmith';

beforeEach(() => {
  clearV1();
});

// testing if authRegisterV1 functions properly given valid input
describe('authRegisterV1 test return value', () => {
  test('correct return type', () => {
    const result = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);

    expect(result).toStrictEqual(
      expect.objectContaining({
        authUserId: expect.any(Number),
      })
    );
  });

  test('correctly updates dataStore', () => {
    const result = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);

    const userData = userProfileV2(result.authUserId, result.authUserId);

    expect(userData).toStrictEqual({
      user: {
        uId: result.authUserId,
        email: EMAIL_VALID,
        nameFirst: FIRSTNAME_VALID,
        nameLast: LASTNAME_VALID,
        handleStr: HANDLE_VALID
      }
    });
  });

  // generates unique uId
  test('generates unique uId for second user', () => {
    const result1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const result2 = authRegisterV1(EMAIL_VALID_2, 'i_like_unicorns_1', 'Josh', 'Lim');

    expect(result1.authUserId).not.toEqual(result2.authUserId);
  });

  // correctly handles case with duplicate handles for three users
  test('generates unique handleStr for second and third user', () => {
    const result1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    const result2 = authRegisterV1(EMAIL_VALID_2, 'i_like_unicorns_1', FIRSTNAME_VALID, LASTNAME_VALID);
    const result3 = authRegisterV1(EMAIL_VALID_3, 'i_like_unicorns_1', FIRSTNAME_VALID, LASTNAME_VALID);

    const userData1 = userProfileV2(result1.authUserId, result1.authUserId);
    const userData2 = userProfileV2(result2.authUserId, result2.authUserId);
    const userData3 = userProfileV2(result3.authUserId, result3.authUserId);

    const userHandle1 = userData1.user.handleStr;
    const userHandle2 = userData2.user.handleStr;
    const userHandle3 = userData3.user.handleStr;

    expect(userHandle1).toBeDefined();
    expect(userHandle2).toBeDefined();
    expect(userHandle3).toBeDefined();

    expect(userHandle1).not.toEqual(userHandle2);
    expect(userHandle1).not.toEqual(userHandle3);
    expect(userHandle2).not.toEqual(userHandle3);

    expect(userHandle1).toStrictEqual(HANDLE_VALID);
    expect(userHandle2).toStrictEqual(userHandle1 + '0');
    expect(userHandle3).toStrictEqual(userHandle1 + '1');
  });

  // correctly handles case with duplicate handles for n users
  const handleStringUniqueUsers = 50;
  test('generates unique handleStr for n users', () => {
    const userHandles = [];
    for (let i = 0; i < handleStringUniqueUsers; i++) {
      const uniqueEmail = i + EMAIL_VALID;

      const result = authRegisterV1(uniqueEmail, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);

      const userData = userProfileV2(result.authUserId, result.authUserId);
      userHandles.push(userData.user.handleStr);
    }

    for (const index in userHandles) {
      let suffix = `${index - 1}`;
      if (parseInt(index) === 0) {
        suffix = '';
      }
      expect(userHandles[index]).toBe(`${HANDLE_VALID}${suffix}`);
    }
  });

  // correctly generates handleStr without non-alphanumeric characters
  test('generates lowercase handleStr without non-alphanumeric characters', () => {
    const result = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, '.1?!Hay^* dEn0', '-~00S+m./1th*(-}');

    const userData = userProfileV2(result.authUserId, result.authUserId);
    const userHandle = userData.user.handleStr;

    expect(userHandle).toBeDefined();
    expect(userHandle).toStrictEqual('1hayden000sm1th');
  });

  // correctly generates handleStr of correct length ( <= 20 )
  test('generates handleStr of correct length ( <= 20 )', () => {
    const result = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, 'H.A.Y.D.E.N.Hayden', 'smith.S.M.I.T.H');

    const userData = userProfileV2(result.authUserId, result.authUserId);
    const userHandle = userData.user.handleStr;

    expect(userHandle).toBeDefined();

    expect(userHandle.length).toBeLessThanOrEqual(20);
    expect(userHandle).toStrictEqual('haydenhaydensmithsmi');
  });

  // correctly transforms duplicate handleStr that is too long
  test('correctly transforms duplicate handleStr that is too long', () => {
    const result1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, 'H.A.Y.D.E.N.Hayden', 'smith.S.M.I.T.H');
    const result2 = authRegisterV1(EMAIL_VALID_2, PASSWORD_VALID, 'H.A.Y.%D.E.N.Hayden', 'smith.S.M.I.T.H');

    const userHandle1 = userProfileV2(result1.authUserId, result1.authUserId).user.handleStr;
    const userHandle2 = userProfileV2(result2.authUserId, result2.authUserId).user.handleStr;

    expect(userHandle1).toBeDefined();
    expect(userHandle1).toStrictEqual('haydenhaydensmithsmi');

    expect(userHandle2).toBeDefined();
    expect(userHandle2).toStrictEqual('haydenhaydensmithsmi0');
  });
});

// testing if authRegisterV1 returns errors where needed
describe.each([
  ['invalid email', 'abc123@unsw', PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID],
  ['password length < 6', EMAIL_VALID, 'abc', FIRSTNAME_VALID, LASTNAME_VALID],
  ['firstName length < 1', EMAIL_VALID, PASSWORD_VALID, '', LASTNAME_VALID],
  ['firstName length > 50', EMAIL_VALID, PASSWORD_VALID, 'HaydenHaydenHaydenHaydenHaydenHaydenHaydenHaydenHayden', LASTNAME_VALID],
  ['lastName length < 1', EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, ''],
  ['lastName length > 50', EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, 'SmithSmithSmithSmithSmithSmithSmithSmithSmithSmithSmith'],
  ['first and last name all special characters', EMAIL_VALID, PASSWORD_VALID, '.,/;[][][][]```--===-', './.-=`/[]][;]'],
])('authRegisterV1 error handling', (error, email, password, firstName, lastName) => {
  test(`returns error upon ${error}`, () => {
    const result = authRegisterV1(email, password, firstName, lastName);
    expect(result).toStrictEqual(ERROR);
  });
});

describe('authRegisterV1 error handling', () => {
  test('returns error upon taken email', () => {
    const result1 = authRegisterV1(EMAIL_VALID, PASSWORD_VALID, FIRSTNAME_VALID, LASTNAME_VALID);
    expect(result1).not.toStrictEqual(ERROR);
    const result2 = authRegisterV1(EMAIL_VALID, 'imposter', 'Among', 'Us');
    expect(result2).toStrictEqual(ERROR);
  });
});
