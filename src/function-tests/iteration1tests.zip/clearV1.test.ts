// @ts-nocheck

import { clearV1 } from '../other';
// import { channelsCreateV1, channelsListV1, channelsListallV1 } from './../channels.js';
import { authLoginV1, authRegisterV1 } from '../auth';

/* test('Basic clear test', () => {
  let originalData = getData();
  let dummyData = {' a key' : 'silly dummy data to store'};
  setData(dummyData);
  clearV1();
  let clearedData = getData();
  expect(clearedData).toMatchObject(originalData);
}); */

const usrEmail = 'cool.user@hotmail.com.au';
const usrPassword = 'password12345!';
const usrFName = 'Brandon';
const usrLName = 'Sanderson';

describe('Basic test for clearV1', () => {
  test('test that everything works without clearV1', () => {
    clearV1();
    const usrId = authRegisterV1(usrEmail, usrPassword, usrFName, usrLName);
    // console.log(usrId);
    const loginReturn = authLoginV1(usrEmail, usrPassword);
    // console.log(loginReturn);
    expect(loginReturn).not.toMatchObject({ error: 'error' });
    // console.log(channelsListV1(usrId));
  });
  test('now test that clearV1 actually clears the data stored in the first test', () => {
    clearV1();
    const loginReturn2 = authLoginV1(usrEmail, usrPassword);
    // console.log(loginReturn2);
    expect(loginReturn2).toMatchObject({ error: 'error' });
  });
});
