// @ts-nocheck

import { channelMessagesV1, channelJoinV1 } from '../channel';
import { clearV1 } from '../other';
import { channelsCreateV1 } from '../channels';
import { authRegisterV1 } from '../auth';

/**
 * Tests Outline:
 * 1. General Tests for expected results
 * 2. Invalid values passed into function
 * 3. Edge case testing
 *
 */

// testing is limited for now as there is no function that can create messages
// inital testing will expect the function to return either an error object or
// an empty messages array

const ERROR = { error: 'error' };

describe('0. Pre-sendMessage function implementation testing', () => {
  const start = 0;
  const isPublic = true;
  const GOOD_RESULT = {
    messages: [],
    start: 0,
    end: -1,
  };
  beforeEach(() => {
    clearV1();
  });
  test('0.1. Single channel and user', () => {
    const authUser = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const authId = authUser.authUserId;
    const channel = channelsCreateV1(authId, 'Test1', isPublic);
    const channelId = channel.channelId;

    expect(channelMessagesV1(authId, channelId, start)).toStrictEqual(GOOD_RESULT);
  });
  test('0.2. Single channel, two users', () => {
    const authUser1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const authID1 = authUser1.authUserId;
    const authUser2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');
    const authID2 = authUser2.authUserId;
    const channel = channelsCreateV1(authID1, 'Test2', isPublic);
    const channelId = channel.channelId;
    channelJoinV1(authID2, channelId);

    expect(channelMessagesV1(authID1, channelId, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(authID2, channelId, start)).toStrictEqual(GOOD_RESULT);
  });
  test('0.3. Two channels, two users with one user in both', () => {
    const authUser1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const authID1 = authUser1.authUserId;
    const authUser2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');
    const authID2 = authUser2.authUserId;
    let channel = channelsCreateV1(authID1, 'Test3.1', isPublic);
    const channelId1 = channel.channelId;
    channelJoinV1(authID2, channelId1);
    channel = channelsCreateV1(authID2, 'Test3.2', isPublic);
    const channelId2 = channel.channelId;

    expect(channelMessagesV1(authID1, channelId1, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(authID2, channelId1, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(authID2, channelId2, start)).toStrictEqual(GOOD_RESULT);
  });
  test('0.4. Five users for one channel', () => {
    const authID1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const user1 = authID1.authUserId;
    const authID2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');
    const user2 = authID2.authUserId;
    const authID3 = authRegisterV1('aperson@outlook.com', 'qwerty', 'Bob', 'Marley');
    const user3 = authID3.authUserId;
    const authID4 = authRegisterV1('student@unsw.com', 'zxcvbb', 'Sam', 'Foo');
    const user4 = authID4.authUserId;
    const authID5 = authRegisterV1('maybe@gmail.com', 'asdfdsfsdfg', 'Water', 'Fire');
    const user5 = authID5.authUserId;
    const channel = channelsCreateV1(user1, 'Test4', isPublic);
    const channelId = channel.channelId;
    channelJoinV1(user2, channelId);
    channelJoinV1(user3, channelId);
    channelJoinV1(user4, channelId);
    channelJoinV1(user5, channelId);

    expect(channelMessagesV1(user1, channelId, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user2, channelId, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user3, channelId, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user4, channelId, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user5, channelId, start)).toStrictEqual(GOOD_RESULT);
  });
  test('0.5. Five users, 3 channels to somewhat simulate real world', () => {
    const authID1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const user1 = authID1.authUserId;
    const authID2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');
    const user2 = authID2.authUserId;
    const authID3 = authRegisterV1('aperson@outlook.com', 'qwerty', 'Bob', 'Marley');
    const user3 = authID3.authUserId;
    const authID4 = authRegisterV1('student@unsw.com', 'zxcvbb', 'Sam', 'Foo');
    const user4 = authID4.authUserId;
    const authID5 = authRegisterV1('maybe@gmail.com', 'asdfdsfsdfg', 'Water', 'Fire');
    const user5 = authID5.authUserId;
    let channelCreated = channelsCreateV1(user1, 'Test5.1', true);
    const channelId1 = channelCreated.channelId;
    channelCreated = channelsCreateV1(user3, 'Test5.2', true);
    const channelId2 = channelCreated.channelId;
    channelCreated = channelsCreateV1(user5, 'Test5.3', true);
    const channelId3 = channelCreated.channelId;
    channelJoinV1(user2, channelId1);
    channelJoinV1(user2, channelId1);
    channelJoinV1(user3, channelId3);
    channelJoinV1(user4, channelId3);
    channelJoinV1(user5, channelId1);
    channelJoinV1(user5, channelId2);

    expect(channelMessagesV1(user1, channelId1, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user2, channelId1, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user3, channelId2, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user3, channelId3, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user4, channelId3, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user5, channelId1, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user5, channelId2, start)).toStrictEqual(GOOD_RESULT);
    expect(channelMessagesV1(user5, channelId3, start)).toStrictEqual(GOOD_RESULT);
  });
  test('0.6. Invalid authUserId', () => {
    const authUser = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const authId = authUser.authUserId;
    const channel = channelsCreateV1(authId, 'Test6', isPublic);
    const channelId = channel.channelId;

    expect(channelMessagesV1(2, channelId, start)).toStrictEqual(ERROR);
  });
  test('0.7. Invalid channelId', () => {
    const authUser = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const authId = authUser.authUserId;
    const channel = channelsCreateV1(authId, 'Test7', isPublic);
    const channelId = channel.channelId;

    expect(channelMessagesV1(authId, 2, start)).toStrictEqual(ERROR);
  });
  test('0.8. Invalid start', () => {
    const authUser = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const authId = authUser.authUserId;
    const channel = channelsCreateV1(authId, 'Test8', isPublic);
    const channelId = channel.channelId;

    expect(channelMessagesV1(authId, channelId, -999)).toStrictEqual(ERROR);
  });
  test('0.9. User not in channel', () => {
    const authID1 = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    const user1 = authID1.authUserId;
    const authID2 = authRegisterV1('anotheremail@yahoo.com', 'letters67', 'Bill', 'Harvey');
    const user2 = authID2.authUserId;
    let channel = channelsCreateV1(user1, 'Test9.1', isPublic);
    const channelId1 = channel.channelId;
    channel = channelsCreateV1(user2, 'Test9.2', isPublic);
    const channelId2 = channel.channelId;

    expect(channelMessagesV1(user1, channelId2, start)).toStrictEqual(ERROR);
    expect(channelMessagesV1(user2, channelId1, start)).toStrictEqual(ERROR);
  });
});

// starter code for when a message create function is implemented
/** describe('1. General Tests', () => {
  test('1.1. One channel, generate few messages', () => {
    clearV1();

    // create user
    // create channel
    // create messages
    // expect results

    let authUser = authRegisterV1('example@gmail.com', 'pass123', 'Hayden', 'Smith');
    let channelId = channelsCreateV1(authUser.authUserId, 'Test', 1);
    // cant create messages because there is no function that returns a channel
    // object with the messages array

    const result = channelMessagesV1('authUserId', 'channelId', 'start');
    expect(result).toEqual({
      messages: [],
      start: 0,
      end: -1,
    });
  });
});

*/
